export interface ResultadoDto{
    status: boolean;
    mensagem: string;
}
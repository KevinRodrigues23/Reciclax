export class UsuarioCadastrarDto{
    id: number;
    usuario: string;
    nome: string;
    telefone: string;
    email: string;
    senha: string;
}
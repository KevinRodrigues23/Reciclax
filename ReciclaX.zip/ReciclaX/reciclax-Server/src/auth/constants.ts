export const jwtConstants = {
    secret: 'SobradoEVida34',
  };
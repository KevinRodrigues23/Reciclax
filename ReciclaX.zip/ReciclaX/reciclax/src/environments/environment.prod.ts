export const environment = {
  production: true,
  /* 
      Aqui vai entrar a variável da api, onde nós atribuiremos o link da api em produção, ou seja, após o deploy, e geração de um domínio
  */
};
